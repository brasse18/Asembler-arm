#include "fs.h"
#include <algorithm>
#include <bits/stdint-uintn.h>
#include <cstdint>
#include <cstdio>
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;
enum rights { read = 1, write = 2 } rights;

int blockSize = 4096;
string currentDirectoryPath = "/";
int currentDirectoryID = 1;

// namn på 101 teken
struct nameIndex {
  const int start = 1;
  const int end = 102;
} nameIndex;

const int rightsIndex = 103;

struct sizeIndex {
  // 16unsind int saved in 2 x 8int variables
  const int first = 104;
  const int second = 105;
} sizeIndex;

struct parentIndex {
  // 16unsind int saved in 2 x 8int variables
  const int first = 106;
  const int second = 107;
} parentIndex;

const int dataStartIndex = 108;
const int nrOfDataBlocks = (blockSize - dataStartIndex) / 2;

FS::FS() { std::cout << "FS::FS()... Creating file system\n"; }

FS::~FS() {}

string FS::getNameFromPath(string path) {
  string out = "";
  std::stringstream test(path);
  std::string segment;
  std::vector<std::string> seglist;

  while (std::getline(test, segment, '/')) {
    seglist.push_back(segment);
  }
  out = seglist.at(seglist.size() - 1);
  return out;
}

// formats the disk, i.e., creates an empty file system
// DONE
int FS::format() {
  // först är antal entries
  std::cout << "FS::format()\n";
  std::uint8_t dataBlock[blockSize];
  for (int i = 0; i < blockSize; i++) {
    dataBlock[i] = 0;
  }

  dataBlock[0] = 1;
  dataBlock[1] = 1;

  disk.write(0, dataBlock);
  // disk.read(0, dataBlock);
  std::uint8_t rootDir[blockSize];
  for (int i = 0; i < blockSize; i++) {
    rootDir[i] = 0;
  }
  rootDir[0] = 69;
  rootDir[nameIndex.start] = '/';
  int tempSizeVar = 1024;
  int temp = (tempSizeVar >> 8); // high byte (0x12)
  rootDir[sizeIndex.first] = temp;
  temp = tempSizeVar & 0xff; // low byte (0x34)
  rootDir[sizeIndex.second] = temp;
  rootDir[rightsIndex] = 3;
  disk.write(1, rootDir);

  // testCreate(); OK
  // testCp(); OK
  // testRm(); OK
  // testMV(); OK
  // testCd(); OK

  return 0;
}

void FS::testCp() {
  cout << "Testar cp" << endl;
  create("fil1");
  cout << "Test1 fil copy to fill" << endl;
  cp("fil1", "fil2");
  ls();
  mkdir("map");
  cout << "Test relative copy" << endl;
  cp("fil1", "map/fil3");
  cp("map/fil3", "fil4");
  ls();
  cout << "Test apsolut copy" << endl;
  cp("fil2", "/map/fil5");
  cp("/map/fil5", "fil6");
  ls();
  cout << "Test copy of non existent file" << endl;
  cp("asdasdasd", "ll");
  ls();
  cout << "Test copy file to non existing folder" << endl;
  cp("fil1", "/gg/fel");
  ls();
  cout << "Slut av test" << endl;
}

void FS::testRm() {
  cout << "Testar rm" << endl;
  create("gg");
  mkdir("map");
  create("/map/hh");
  create("/map/gg");
  create("/map/jj");
  cd("map");
  ls();
  cd("..");
  pwd();
  rm("map/hh");
  rm("/map/gg");
  cd("/map");
  ls();
  cd("/");
  cout << "Slut av test" << endl;
}

void FS::testCreate() {
  create("gg");
  ls();
  cat("gg");
  create("/map/hh");
  mkdir("map");
  create("map/jj");
  create("/map/gg");
  cd("/map");
  ls();
  cat("gg");
  cat("jj");
  cout << "Slut av test" << endl;
}

void FS::testMV() {
  cout << "Testar mv" << endl;
  mkdir("map"); // id 2
  create("ny"); // id 3
  ls();
  cout << "Test apsolut path" << endl;
  mv("ny", "map/nyny");
  ls();
  cd("map");
  ls();
  cout << "Test relative path" << endl;
  mv("/map/nyny", "/ny2");
  ls();
  cd("/");
  ls();
  cout << "Test to move non existent file" << endl;
  mv("akjsdlkajslkd", "fel");
  ls();
  create("test"); // id 6
  ls();
  cout << "Test to move replase file" << endl;
  mv("ny2", "test");
  ls();
  cout << "Slut av test" << endl;
}

void FS::testCd() {
  cout << "Testar cd" << endl;
  mkdir("map");
  mkdir("/map/map2");
  mkdir("/map/map2/map3");
  cout << "Testar relative cd map" << endl;
  cout << "förventad out put: /map" << endl;
  cd("map");
  pwd();
  cout << "Testar apsolut cd /map/map2/map3" << endl;
  cout << "förventad out put: /map/map2/map3" << endl;
  cd("/map/map2/map3");
  pwd();
  cout << "Testar cd /" << endl;
  cout << "förventad out put: /" << endl;
  cd("/");
  pwd();
  cout << "Slut av test" << endl;
}

int FS::getIdAfterStepInToDir(string path, int workingDirID) {
  int out = currentDirectoryID;
  std::stringstream test(path);
  std::string segment;
  std::vector<std::string> seglist;

  if (path.at(0) == '/') {
    out = 1;
  }

  while (std::getline(test, segment, '/')) {
    seglist.push_back(segment);
  }

  for (int pathSteper = 1; pathSteper < seglist.size(); pathSteper++) {
    out = getEntryByName(seglist.at(pathSteper), out);
  }
  if (out == 0) {
    out = -1;
  }
  return out;
}

uint16_t FS::convertInt(uint8_t x, uint8_t y) {
  uint16_t out = x * 256 + y;
  return out;
}

uint8_t FS::splitInt(int z, int xOrY) { // 0 gives x, anything else gives
                                        // y
  uint8_t out = 0;
  int temp = 0;
  int parentVar = z;
  if (xOrY == 0) {
    temp = parentVar >> 8; // x or high byte (0x12)
    out = temp;
  } else {
    temp = parentVar & 0xFF; // y or low byte (0x34)
    out = temp;
  }

  return out;
}

// den svarar med id av det namnet man skickar in i den mappen man vill leta i
// DONE
int FS::getEntryByName(std::string entryName, int mapIdToSearchIn) {
  std::uint8_t dataBlockDir[blockSize];
  std::uint8_t dataBlockOfEntry[blockSize];
  int entryNameSteper = nameIndex.start;
  int entrySteper = dataStartIndex;
  bool nameIsOk = true;
  bool fileExist = false;
  uint16_t entryIndex = 0;
  int out = 0;

  disk.read(mapIdToSearchIn, dataBlockDir);

  for (int entry = dataStartIndex; entry < dataStartIndex + 6; entry += 2) {
    entryIndex = convertInt(dataBlockDir[entry], dataBlockDir[entry + 1]);
    if (entryIndex != 0) {
      nameIsOk = true;
      disk.read(entryIndex, dataBlockOfEntry);
      for (int nameSteper = nameIndex.start; nameSteper < nameIndex.end;
           nameSteper++) {
        if (nameSteper <= entryName.length()) {
          if (dataBlockOfEntry[nameSteper] !=
              entryName.at(nameSteper - nameIndex.start)) {
            nameIsOk = false;
          }
        } else {
          if (dataBlockOfEntry[nameSteper] != 0) {
            nameIsOk = false;
          }
        }
      }
      if (nameIsOk) {
        out = entryIndex;
        break;
      }
    }
  }
  return out;
}

int FS::getNextEmptyBlock() {
  int out = 0;
  std::uint8_t dataBlockFs[blockSize];
  disk.read(0, dataBlockFs);
  for (int i = 0; i < blockSize; i++) {
    if (dataBlockFs[i] == 0) {
      out = i;
      break;
    }
  }
  return out;
}

bool FS::doIHavePermission(uint8_t datablock[], int right) {
  int fileRights = datablock[rightsIndex];
  if (right == read) { // check enum stuff for 'read'
    if (fileRights < 3) {
      cout << "ERROR! Reading access rights required!" << endl;
      return false;
    }
  } else if (right == write) { // check enum stuff for 'write'
    if (fileRights == 0 || fileRights == 1 || fileRights == 4 ||
        fileRights == 5) {
      cout << "ERROR! Writing access rights required!" << endl;
      return false;
    }
  }
  return true;
}

int FS::getNextEmptyPositionToWriteOn(uint8_t data[]) {
  int out = 0;
  for (int i = dataStartIndex; i < BLOCK_SIZE; i += 2) {
    if (convertInt(data[i], data[i + 1]) == 0) {
      out = i;
      break;
    }
  }
  return out;
}

int FS::findWorkingID(string filepath) {

  string fileName = filepath;
  int idToReturn = -1;

  if (filepath.find('/') == -1) {

    idToReturn = 0; // currentDirectory set later
  } else {
    if (filepath[0] != '/') {
      string absolutePath = currentDirectoryPath;
      absolutePath.append(filepath);
      filepath = absolutePath;
    }
    fileName = getNameFromPath(filepath);
    filepath.resize(filepath.length() - fileName.length());

    idToReturn = getIdAfterStepInToDir(filepath, currentDirectoryID);
  }

  return idToReturn;
}

// create <filepath> creates a new file on the disk, the data content is
// written on the following rows (ended with an empty row)
// DONE
int FS::create(std::string filepath) {
  std::cout << "FS::create(" << filepath << ")\n";
  int fileNameCount = 0;
  int newFileId = 0;
  int newFileDataBlockId = 0;
  int workingDirID = currentDirectoryID;
  string fileName = filepath;
  uint8_t dataBlockFs[blockSize];
  uint8_t newDataBlock[blockSize];
  uint8_t currentDir[blockSize];
  uint8_t temp[blockSize];
  uint8_t workingDirDataBlock[blockSize];

  if (filepath == "") {
    cout << "ERROR! Please enter a filename!" << endl;
    return 0;
  }

  workingDirID = findWorkingID(filepath);

  if (workingDirID == -1) {
    cout << "ERROR! Path doesn't exist!" << endl;
    return 0;
  } else if (workingDirID == 0) {
    workingDirID = currentDirectoryID;
    fileName = filepath;
  } else {
    fileName = getNameFromPath(filepath);
  }
  disk.read(workingDirID, workingDirDataBlock);

  if (getEntryByName(fileName, workingDirID) != 0) {
    cout << "File already exists!" << endl;
  } else {
    for (int i = 0; i < blockSize; i++) {
      newDataBlock[i] = 0;
    }

    string input = "";
    cout << "Enter file data: ";
    getline(cin, input);

    //------ Test start
    // input = "";
    // for (int i = 0; i < 4400; i++) {
    //   input.append(
    //       "A"); // REMEMBER THIS SHIT REMEMBER THIS SHIT REMEMBER THIS SHIT
    //             // REMEMBER THIS SHIT REMEMBER THIS SHIT REMEMBER THIS SHIT
    //             // REMEMBER THIS SHIT REMEMBER THIS SHITREMEMBER THIS SHIT
    //             // REMEMBER THIS SHIT REMEMBER REMEMBER THIS SHIT REMEMBER
    //             // THIS SHIT REMEMBER THIS SHIT REMEMBER THIS SHIT REMEMBER
    //             // THIS SHIT REMEMBER THIS SHIT REMEMBER THIS SHITREMEMBER
    // }
    // input.append("T");
    //------ Test end

    int fileDataSize = input.length();

    int nrOfDataBoxes = 0;
    nrOfDataBoxes = input.length() / blockSize;
    if (nrOfDataBoxes < (double)input.length() / blockSize) {
      nrOfDataBoxes++;
    }

    uint8_t dataBox[nrOfDataBoxes][blockSize];
    int counter = 0;
    for (int i = 0; i < nrOfDataBoxes; i++) {
      for (int j = 0; j < blockSize; j++) {
        if (j + (i * BLOCK_SIZE) < input.length()) {
          dataBox[i][j] = input.at(j + (i * blockSize));
        } else {
          dataBox[i][j] = 0;
        }
      }
    }

    // läser data från filsystemet som ex var nästa
    disk.read(workingDirID, currentDir);
    // uppdaterar nuvarande mapp
    // med den nya filens id
    newFileId = getNextEmptyBlock();
    currentDir[getNextEmptyPositionToWriteOn(currentDir)] =
        splitInt(newFileId, 0);
    currentDir[getNextEmptyPositionToWriteOn(currentDir) + 1] =
        splitInt(newFileId, 1);
    // skriver den nuvarande mapen till disk
    disk.write(workingDirID, currentDir);

    // läser data från filsystemet
    disk.read(0, dataBlockFs);
    // uppdatera filsystemet För den nya data blocket till filen
    dataBlockFs[newFileId] = 1;
    // skriv uppdatering till disk
    disk.write(0, dataBlockFs);

    // ------- skapa den nya filen -----------
    newDataBlock[0] = 1; // file type. 1 is file and 2 is directory
    for (int i = nameIndex.start; i <= nameIndex.end; i++) {

      if (fileName.length() <= i - nameIndex.start) {
        newDataBlock[i] = 0;
      } else {
        newDataBlock[i] = fileName.at(fileNameCount);
      }
      fileNameCount++;
    }

    // skriver rättigheten
    // 1 1 0 = 3
    newDataBlock[rightsIndex] = 6;
    // skriver in storleken
    newDataBlock[sizeIndex.first] = splitInt(fileDataSize, 0);
    newDataBlock[sizeIndex.second] = splitInt(fileDataSize, 1);

    // set parent id
    newDataBlock[parentIndex.first] = splitInt(workingDirID, 0);
    newDataBlock[parentIndex.second] = splitInt(workingDirID, 1);

    // ----- end of data inläsning --------

    // läser data från filsystemet
    disk.read(0, dataBlockFs);
    // uppdatera filsystemet För den nya filen
    dataBlockFs[newFileDataBlockId] = 1;
    // sets the correct amount of data blocks to busy
    for (int i = 0; i < nrOfDataBoxes; i++) {

      // sätt id till nytt data block
      newFileDataBlockId = getNextEmptyBlock();
      int tempIndex = getNextEmptyPositionToWriteOn(newDataBlock);
      newDataBlock[tempIndex] = splitInt(newFileDataBlockId, 0);
      newDataBlock[tempIndex + 1] = splitInt(newFileDataBlockId, 1);

      disk.read(0, dataBlockFs);
      // uppdatera filsystemet För den nya filen data block
      dataBlockFs[newFileDataBlockId] = 1;

      // skriv uppdatering till disk
      disk.write(0, dataBlockFs);

      // skriv nya filens data till disk
      disk.write(newFileDataBlockId, dataBox[i]);
    }

    // skriv uppdatering till disk
    // disk.write(0, dataBlockFs);

    // updaterar vilka data block som har data
    // skriv den nya filen till disk
    disk.write(newFileId, newDataBlock);
  }

  // printDataBlock(2, true);

  return 0;
}

bool FS::isDir(int i) {
  bool out = false;
  const int fileOrDir = 0;
  std::uint8_t dataBlockOfEntry[blockSize];
  disk.read(i, dataBlockOfEntry);
  if (dataBlockOfEntry[fileOrDir] == 69 || dataBlockOfEntry[fileOrDir] == 2) {
    out = true;
  }
  return out;
}

// function to print data block
void FS::printDataBlock(int id, bool printAsInt) {
  // cout << "data Block: " << id << endl;
  uint8_t dataBlock[blockSize];
  disk.read(id, dataBlock);
  if (id == 0) {
    for (int i = 0; i < 10; i++) {
      string temp = "";
      if ((bool)dataBlock[i]) {
        temp = "True";
      } else {
        temp = "False";
      }
      cout << i << ": " << temp << "         ";
      if (i == 4) {
        cout << endl;
      }
    }
  } else if (printAsInt) {
    if (dataBlock[0] == 1) {
      cout << "file" << endl;
    } else if (dataBlock[0] == 69) {
      cout << "Root" << endl;
    } else {
      cout << "Dir" << endl;
    }
    cout << "Name: ";
    for (int i = nameIndex.start; i < nameIndex.end; i++) {
      cout << (char)dataBlock[i];
    }
    cout << endl << "Rättigheter: " << (int)dataBlock[rightsIndex] << endl;
    cout << "size: " << (int)dataBlock[sizeIndex.first] << " "
         << (int)dataBlock[sizeIndex.second] << endl;
    cout << "Förälder: " << (int)dataBlock[parentIndex.first] << " "
         << (int)dataBlock[parentIndex.second] << endl;
    for (int i = 0; i < 10; i += 2) {
      cout << "DataBlock " << i / 2 << ": "
           << (int)dataBlock[i + dataStartIndex] << " "
           << (int)dataBlock[i + dataStartIndex + 1] << endl;
    }

  } else {
    for (int i = 0; i < blockSize; i++) {
      cout << (char)dataBlock[i];
    }
  }

  cout << endl;
}

int FS::getDataBlockFromEntry(int idOfData, int entryId) {
  int out = 0;
  std::uint8_t dataBlockOfEntry[blockSize];
  disk.read(entryId, dataBlockOfEntry);
  if (dataStartIndex + (idOfData * 2) + 1 < blockSize) {
    out = convertInt(dataBlockOfEntry[dataStartIndex + (idOfData * 2)],
                     dataBlockOfEntry[dataStartIndex + (idOfData * 2) + 1]);
  }
  return out;
}

// cat <filepath> reads the content of a file and prints it on the screen
// Done fungera med relativa sökvägar
int FS::cat(std::string filepath) {
  std::cout << "FS::cat(" << filepath << ")\n";

  std::uint8_t dataBlockOfEntry[blockSize];
  int fileToCat = 0;

  if (filepath.find('/') == -1) {
    fileToCat = getEntryByName(filepath, currentDirectoryID);
  } else {
    fileToCat = getIdAfterStepInToDir(filepath, currentDirectoryID);
  }

  if (fileToCat != 0) {
    if (!isDir(fileToCat)) {
      disk.read(fileToCat, dataBlockOfEntry);
      if (dataBlockOfEntry[rightsIndex] < 4) {
        cout << "Error! File does not have reading access rights!" << endl;
        return 0;
      }
      int speper = 0;
      cout << "----DATA----" << endl;
      while (getDataBlockFromEntry(speper, fileToCat) != 0) {
        printDataBlock(getDataBlockFromEntry(speper++, fileToCat), false);
      }
      cout << "----DATA----" << endl;
    } else {
      cout << "This is a directory!" << endl;
    }
  } else {
    cout << "File does not exist!" << endl;
  }

  return 0;
}

// ls lists the content in the currect directory (files and sub-directories)
// DONE
int FS::ls() {
  std::cout << "FS::ls()\n";
  uint8_t currDataBlock[blockSize];
  uint8_t dataBlockOfEntry[blockSize];
  int steper = dataStartIndex;
  int sizeToPrint;
  // gets current directory
  disk.read(currentDirectoryID, currDataBlock);
  // kontrollerar att vi har rätt rättigheter
  if (!doIHavePermission(currDataBlock, read)) {
    return 0;
  };
  while (steper != blockSize) {
    if (convertInt(currDataBlock[steper], currDataBlock[steper + 1]) != 0) {
      int steperNameIndex = nameIndex.start;
      sizeToPrint = 0;

      disk.read(convertInt(currDataBlock[steper], currDataBlock[steper + 1]),
                dataBlockOfEntry);
      while (steperNameIndex != nameIndex.end + 1) { // start of name segment

        if (dataBlockOfEntry[steperNameIndex] != 0) { // prints name
          cout << (char)(dataBlockOfEntry[steperNameIndex]);
        }
        steperNameIndex++;
      } // end of name segment
      cout << "           ";
      // start of type segment
      string type = "";
      if (dataBlockOfEntry[0] == 1) {
        type = "file";
      } else {

        type = "folder";
      }
      cout << type; // prints type
                    // end of type segment
      cout << "           ";
      // start of access rights segment
      int rightsInt = 0;
      string rightsToPrint = "";
      rightsInt = dataBlockOfEntry[rightsIndex];
      // access rights for read
      if (rightsInt > 3) {
        rightsToPrint += "r";
      } else {
        rightsToPrint += "-";
      }
      // access rights for write
      if (rightsInt == 2 || rightsInt == 3 || rightsInt > 5) {
        rightsToPrint += "w";
      } else {
        rightsToPrint += "-";
      }
      // access rights for execute
      if (rightsInt % 2 == 1) {
        rightsToPrint += "x";
      } else {
        rightsToPrint += "-";
      }
      cout << rightsToPrint; // prints access rights

      //       end of access rights segment
      cout << "           ";
      // start of size segment
      sizeToPrint +=
          convertInt(dataBlockOfEntry[sizeIndex.first],
                     dataBlockOfEntry[sizeIndex.second]); // adds size

      cout << sizeToPrint << endl; // prints size
      // end of size segment
    }
    steper += 2;
  }

  return 0;
}

// cp <sourcefilepath> <destfilepath> makes an exact copy of the file
// <sourcefilepath> to a new file <destfilepath>
int FS::cp(std::string sourcefilepath, std::string destfilepath) {
  std::cout << "FS::cp(" << sourcefilepath << "," << destfilepath << ")\n";
  uint8_t fsDataBlock[blockSize];
  // source veribols
  uint8_t sourceFileBlock[blockSize];
  uint8_t sourceDataBlock[blockSize];
  int sourceWorkingDirId = currentDirectoryID;
  int sourceId = 0;
  string sourceFileName = "";
  // destination veribols
  uint8_t destFileBlock[blockSize];
  uint8_t destDataBlock[blockSize];
  uint8_t destDirDataBlock[blockSize];
  int destWorkingDirId = currentDirectoryID;
  int destId = 0;
  string destFileName = "";
  if (sourcefilepath == "" || destfilepath == "") {
    cout << "Wrong amount of inputs! Please enter a source filepath and a "
            "destination file path!"
         << endl;
    return 0;
  }

  // get sourceWorkingDirId and sourceFileName
  sourceWorkingDirId = findWorkingID(sourcefilepath);
  if (sourceWorkingDirId == 0) {
    sourceWorkingDirId = currentDirectoryID;
    sourceFileName = sourcefilepath;
  } else {
    sourceFileName = getNameFromPath(sourcefilepath);
  }
  if (getEntryByName(sourceFileName, sourceWorkingDirId) == 0) {
    cout << "ERROR! File selected to copy from does not exist!" << endl;
    return 0;
  }

  // get destWorkingDirId and destFileName
  destWorkingDirId = findWorkingID(destfilepath);
  if (destWorkingDirId == 0) {
    destWorkingDirId = currentDirectoryID;
    destFileName = destfilepath;
  } else {
    destFileName = getNameFromPath(destfilepath);
  }

  if (destWorkingDirId == -1) {
    cout << "ERROR! Path to new destenation dose not exist!" << endl;
    return 0;
  }

  if (getEntryByName(destFileName, destWorkingDirId) != 0) {
    cout << "ERROR! File selected to copy to already exists!" << endl;
    return 0;
  }

  sourceId = getEntryByName(sourceFileName, sourceWorkingDirId);

  disk.read(sourceId, sourceFileBlock);
  // kontrollerar att vi har rätt rättigheter
  if (!doIHavePermission(sourceFileBlock, read)) {
    return 0;
  };
  // testar om det är en fil
  if (sourceFileBlock[0] != 1) {
    cout << "ERROR! File selected is a folder!" << endl;
    return 0;
  }
  // get ny id för filen
  destId = getNextEmptyBlock();

  disk.read(0, fsDataBlock);
  fsDataBlock[destId] = 1;
  disk.write(0, fsDataBlock);

  // set to file
  destFileBlock[0] = 1;
  for (int i = 1; i < blockSize; i++) {
    destFileBlock[i] = 0;
  }
  // set namn
  for (int i = nameIndex.start; i < nameIndex.end; i++) {
    // skriv det nya namnet till filen
    if (destFileName.length() > i - nameIndex.start) {
      destFileBlock[i] = destFileName.at(i - nameIndex.start);
      // fyll ut resten av platserna med 0
    } else {
      i = nameIndex.end;
    }
  }

  // set filens rättigheter
  destFileBlock[rightsIndex] = sourceFileBlock[rightsIndex];
  // set filens storlek
  destFileBlock[sizeIndex.first] = sourceFileBlock[sizeIndex.first];
  destFileBlock[sizeIndex.second] = sourceFileBlock[sizeIndex.second];
  // set filens förelder
  destFileBlock[parentIndex.second] = splitInt(destWorkingDirId, 0);
  destFileBlock[parentIndex.second] = splitInt(destWorkingDirId, 1);

  for (int i = 0; i < nrOfDataBlocks; i++) {
    int temp = getDataBlockFromEntry(i, sourceId);
    if (temp != 0) {
      int id = 0;
      disk.read(sourceId, sourceDataBlock);
      id = getNextEmptyBlock();
      int nyPotion = getNextEmptyPositionToWriteOn(destFileBlock);
      destFileBlock[nyPotion] = splitInt(id, 0);
      destFileBlock[nyPotion + 1] = splitInt(id, 1);
      disk.read(temp, destDataBlock);
      disk.write(id, destDataBlock);
      // update file system block
      disk.read(0, fsDataBlock);
      fsDataBlock[id] = 1;
      disk.write(0, fsDataBlock);
      // printDataBlock(0, true);
    }
  }
  disk.write(destId, destFileBlock);
  // printDataBlock(destId, true);
  // update destDir med ny fil
  disk.read(destWorkingDirId, destDirDataBlock);
  int nyPos = getNextEmptyPositionToWriteOn(destDirDataBlock);
  destDirDataBlock[nyPos] = splitInt(destId, 0);
  destDirDataBlock[nyPos + 1] = splitInt(destId, 1);
  disk.write(destWorkingDirId, destDirDataBlock);

  return 0;
}

// mv <sourcepath> <destpath> renames the file <sourcepath> to the name
// <destpath>, or moves the file <sourcepath> to the directory <destpath> (if
// dest is a directory)

int FS::mv(std::string sourcepath, std::string destpath) {
  std::cout << "FS::mv(" << sourcepath << "," << destpath << ")\n";
  std::uint8_t currentDir[blockSize];
  std::uint8_t newDir[blockSize];
  std::uint8_t dataBlockOfEntry[blockSize];
  uint8_t dataBlockFs[blockSize];
  // int dataBlockOfEntryId = 0;
  int workingDirID = currentDirectoryID;
  string fileName = "";
  if (sourcepath == "" || destpath == "") {
    cout << "ERROR! Please enter a source path and a destination path!" << endl;
    return 0;
  }

  // gets name and id from sourcepath
  workingDirID = findWorkingID(sourcepath);
  if (workingDirID == 0) {
    workingDirID = currentDirectoryID;
    fileName = sourcepath;
  } else {
    fileName = getNameFromPath(sourcepath);
  }

  int fileIdToCopy = getEntryByName(fileName, workingDirID);
  disk.read(fileIdToCopy, dataBlockOfEntry);

  // gets name and id from destpath
  string destFileName = "";
  int targetDirID = findWorkingID(destpath);
  if (targetDirID == 0) {
    targetDirID = currentDirectoryID;
    destFileName = destpath;
  } else {
    destFileName = getNameFromPath(destpath);
  }

  if (getEntryByName(fileName, workingDirID) == 0) {
    cout << "ERROR! File selected to move does not exist!" << endl;
    return 0;
  }

  if (getEntryByName(destFileName, targetDirID) != 0) {
    cout << "ERROR! File already exists at specified destination!" << endl;
    // fix overwrite
    while (true) {
      cout << "Would you like to overwrite? Enter 'yes' or 'no': ";
      string answer = "";
      cin >> answer;
      if (answer != "yes" && answer != "no") {
        cout << "\nWrong input, please try again!" << endl;
      } else {
        if (answer == "yes") {
          FS::rm(destpath);
          break;
        } else {
          cout << "Aborting..." << endl;
          return 0;
        }
      }
    }
  }

  // overwrites the new name
  for (int nameSteper = nameIndex.start; nameSteper < nameIndex.end;
       nameSteper++) {
    // skriv det nya namnet till filen
    if (destFileName.length() > nameSteper - nameIndex.start) {
      dataBlockOfEntry[nameSteper] =
          destFileName.at(nameSteper - nameIndex.start);
      // fyll ut resten av platserna med 0
    } else {
      dataBlockOfEntry[nameSteper] = 0;
    }
  }
  dataBlockOfEntry[parentIndex.first] = splitInt(targetDirID, 0);
  dataBlockOfEntry[parentIndex.second] = splitInt(targetDirID, 1);

  disk.write(fileIdToCopy, dataBlockOfEntry);

  // reads current Dir
  int index = 0;
  disk.read(workingDirID, currentDir);

  for (int i = 0; i < nrOfDataBlocks; i++) {
    int temp = getDataBlockFromEntry(i, workingDirID);
    if (temp == fileIdToCopy) {
      index = i;
      i = nrOfDataBlocks;
    }
  }
  currentDir[dataStartIndex + index * 2] = 0;
  currentDir[dataStartIndex + 1 + index * 2] = 0;
  disk.write(workingDirID, currentDir);
  // reading target directory
  disk.read(targetDirID, newDir);
  index = getNextEmptyPositionToWriteOn(newDir);
  newDir[index] = splitInt(fileIdToCopy, 0);
  newDir[index + 1] = splitInt(fileIdToCopy, 1);

  disk.write(targetDirID, newDir);

  return 0;
}

// rm <filepath> removes / deletes the file <filepath>
// öppna filsystemet, ta bitarna och sätta dem till 0, mappen som filen ligger
// i. dess datapointer ska skrivas till 0. uppdatera filsystemet
int FS::rm(std::string filepath) {
  std::cout << "FS::rm(" << filepath << ")\n";
  uint8_t fs[blockSize];
  uint8_t workingDirDataBlock[blockSize];
  uint8_t file_data[blockSize];
  int workingDirID = currentDirectoryID;
  std::string fileName = "";
  int fileID = 0;
  int fileIdToRemove = 0;

  if (filepath == "") {
    cout << "ERROR! Please enter a filename!" << endl;
    return 0;
  }

  // om det inte finns en / så
  workingDirID = findWorkingID(filepath);
  if (workingDirID == 0) {
    workingDirID = currentDirectoryID;
    fileName = filepath;
  } else {
    fileName = getNameFromPath(filepath);
  }

  disk.read(workingDirID, workingDirDataBlock);
  fileIdToRemove = getEntryByName(fileName, workingDirID);

  if (fileIdToRemove != 0) {

    for (int i = dataStartIndex; i < BLOCK_SIZE; i += 2) {
      if (convertInt(workingDirDataBlock[i], workingDirDataBlock[i + 1]) ==
          fileIdToRemove) {
        fileID = i;
        break;
      }
    }
    disk.read(fileIdToRemove, file_data);

    if (file_data[0] == 2) {
      cout << "Error! Cannot remove a directory" << endl;
      return 0;
    }
    disk.read(0, fs);

    for (int i = dataStartIndex; i < BLOCK_SIZE; i += 2) {
      int var = convertInt(file_data[i], file_data[i + 1]);
      if (i)
        if (var != 0) {
          fs[var] = 0;
        }
    }
    workingDirDataBlock[fileID] = 0;
    workingDirDataBlock[fileID + 1] = 0;
    disk.write(workingDirID, workingDirDataBlock);

    // reading file system

    fs[fileIdToRemove] = 0;
    disk.write(0, fs);

  } else {
    cout << "Error! Could not find file to remove!" << endl;
  }
  // printDataBlock(0, false);
  // printDataBlock(1, true);
  // printDataBlock(5, true);
  // printDataBlock(6, true);

  return 0;
}

// append <filepath1> <filepath2> appends the contents of file <filepath1> to
// the end of file <filepath2>. The file <filepath1> is unchanged.
int FS::append(std::string filepath1, std::string filepath2) {
  std::cout << "FS::append(" << filepath1 << "," << filepath2 << ")\n";
  uint8_t fileSource[BLOCK_SIZE];
  uint8_t fileTarget[BLOCK_SIZE];
  string fileName1 = filepath1;
  string fileName2 = filepath2;
  int workingDirID1 = currentDirectoryID;
  int workingDirID2 = currentDirectoryID;

  // om det inte finns en / så
  workingDirID1 = findWorkingID(filepath1);
  if (workingDirID1 == -1) {
    cout << "ERROR! Path doesn't exist!" << endl;
    return 0;
  } else if (workingDirID1 == 0) {
    workingDirID1 = currentDirectoryID;
    fileName1 = filepath1;
  } else {
    fileName1 = getNameFromPath(filepath1);
  }

  // om det inte finns en / så
  workingDirID2 = findWorkingID(filepath2);
  if (workingDirID2 == -1) {
    cout << "ERROR! Path doesn't exist!" << endl;
    return 0;
  } else if (workingDirID2 == 0) {
    workingDirID2 = currentDirectoryID;
    fileName2 = filepath2;
  } else {
    fileName2 = getNameFromPath(filepath2);
  }
  int sourceID = getEntryByName(fileName1, workingDirID1);

  int targetID = getEntryByName(fileName2, workingDirID2);

  if (sourceID && targetID) {
    disk.read(sourceID, fileSource); // gets file with data to copy from
    disk.read(targetID, fileTarget); // gets file with data to copy to
    // checks access rights
    if (fileSource[rightsIndex] < 3) {
      cout << "ERROR! Source file does not have reading access rights!" << endl;
      return 0;
    }
    if (fileTarget[102] == 0 || fileTarget[102] == 1 || fileTarget[102] == 4 ||
        fileTarget[102] == 5) {
      cout << "ERROR! Target file does not have writing access rights!" << endl;
      return 0;
    }
    int sourceSize1 = fileSource[103];
    int sourceSize2 = fileSource[104];

    int targetSize1 = fileTarget[103];
    int targetSize2 = fileTarget[104];

    int newSize = convertInt(sourceSize1, sourceSize2) +
                  convertInt(targetSize1, targetSize2);

    int tempCounter = 0;
    for (int i = dataStartIndex; i < BLOCK_SIZE; i += 2) {
      int dataToCopy = getDataBlockFromEntry(tempCounter++, sourceID);

      if (dataToCopy != 0) {

        uint8_t tempFile[BLOCK_SIZE];
        int nextEmptyBlock = getNextEmptyBlock(); // next free space on FS
                                                  //
        disk.read(dataToCopy, tempFile);          // reads from fs
        int sizeTemp =
            convertInt(tempFile[sizeIndex.first], tempFile[sizeIndex.second]);

        sizeTemp += BLOCK_SIZE; // appends size
        tempFile[sizeIndex.first] = splitInt(sizeTemp, 0);
        tempFile[sizeIndex.second] = splitInt(sizeTemp, 1);

        disk.write(nextEmptyBlock,
                   tempFile); // writes data to fs

        disk.read(0, tempFile);
        tempFile[nextEmptyBlock] = 1; // reserves space in fs
        disk.write(0, tempFile);      // updates reserved space

        int nextEmptyPos = getNextEmptyPositionToWriteOn(fileTarget);

        fileTarget[nextEmptyPos] = splitInt(nextEmptyBlock, 0);
        fileTarget[nextEmptyPos + 1] = splitInt(nextEmptyBlock, 1);
        disk.write(targetID, fileTarget);
      }
    }
    fileTarget[103] = splitInt(newSize, 0);
    fileTarget[104] = splitInt(newSize, 1);
    disk.write(targetID, fileTarget);
  }
  return 0;
}

// mkdir <dirpath> creates a new sub-directory with the name <dirpath>
// in the current directory
// DONE AND WORKS
int FS::mkdir(std::string dirpath) {
  std::cout << "FS::mkdir(" << dirpath << ")\n";

  int fileBlockCount = 0;
  int newDirId = 0;
  int dirSize = 1337;
  string dirName = dirpath;
  int workingDirID = currentDirectoryID;
  uint8_t dataBlockFs[blockSize];
  uint8_t currentDir[blockSize];
  uint8_t newDataBlock[blockSize];

  workingDirID = findWorkingID(dirpath);
  if (workingDirID == -1) {
    cout << "ERROR! Path doesn't exist!" << endl;
    return 0;
  } else if (workingDirID == 0) {
    workingDirID = currentDirectoryID;
    dirName = dirpath;
  } else {
    dirName = getNameFromPath(dirpath);
  }

  if (getEntryByName(dirpath, workingDirID) != 0) {
    cout << "Directory already exists" << endl;
  } else {

    for (int i = 0; i < blockSize; i++) {
      newDataBlock[i] = 0;
    }
    // läser data från filsystemet som ex var nästa
    disk.read(workingDirID, currentDir);

    // uppdaterar nuvarande mapp
    // med den nya filens id
    newDirId = getNextEmptyBlock();
    currentDir[getNextEmptyPositionToWriteOn(currentDir)] =
        splitInt(newDirId, 0);
    currentDir[getNextEmptyPositionToWriteOn(currentDir) + 1] =
        splitInt(newDirId, 1);
    // skriver den nuvarande mapen till disk
    disk.write(workingDirID, currentDir);

    // läser data från filsystemet
    disk.read(0, dataBlockFs);
    // uppdatera filsystemet För den nya data blocket till filen
    dataBlockFs[newDirId] = 1;
    // skriv uppdatering till disk
    disk.write(0, dataBlockFs);

    // ------- skapa den nya filen -----------
    newDataBlock[0] = 2; // file type. 1 is file and 2 is directory
    for (int i = nameIndex.start; i <= nameIndex.end; i++) {

      if (dirName.length() <= i - nameIndex.start) {
        newDataBlock[i] = 0;
      } else {
        newDataBlock[i] = dirName.at(fileBlockCount);
      }
      fileBlockCount++;
    }

    // skriver rättigheten
    // 1 1 0 = 3
    newDataBlock[rightsIndex] = 3;
    // skriver in storleken
    newDataBlock[sizeIndex.first] = splitInt(dirSize, 0);
    newDataBlock[sizeIndex.second] = splitInt(dirSize, 1);

    // set parent id
    newDataBlock[parentIndex.first] = splitInt(workingDirID, 0);
    newDataBlock[parentIndex.second] = splitInt(workingDirID, 1);

    // ----- end of data inläsning --------

    // updaterar vilka data block som har data

    // skriv den nya filen till disk
    disk.write(newDirId, newDataBlock);
  }

  return 0;
}

int FS::getParentIdFromEntry(int dirId) {
  int out = 1;
  std::uint8_t dataBlockDir[blockSize];
  disk.read(dirId, dataBlockDir);
  out = convertInt(dataBlockDir[parentIndex.first],
                   dataBlockDir[parentIndex.second]);
  return out;
}

string FS::getNameFromEntry(int dirId) {
  string out = "";
  std::uint8_t dataBlockDir[blockSize];
  disk.read(dirId, dataBlockDir);
  for (int i = nameIndex.start; i < nameIndex.end; i++) {
    if (dataBlockDir[i] != 0) {
      out.push_back(dataBlockDir[i]);
    }
  }
  return out;
}

string FS::getDirPath(int id) {
  string out = "/";
  string tempString = "";

  if (id > 1) {
    out = "";
    while (id != 0) {
      if (id == 1) {
        tempString = "/";
        tempString.append(out);
        out = tempString;

        break;
      }
      tempString = getNameFromEntry(id);
      tempString.push_back('/');
      tempString.append(out);
      out = tempString;
      id = getParentIdFromEntry(id);
    }
  }
  if (out.length() > 1) {
    out.resize(out.length() - 1);
  }
  return out;
}

// cd <dirpath> changes the current (working) directory to the directory named
// <dirpath>
int FS::cd(std::string dirpath) {
  std::cout << "FS::cd(" << dirpath << ")\n";
  int workingDirID = currentDirectoryID;
  string folderName = getNameFromEntry(currentDirectoryID);
  int nyId = 0;

  if (dirpath == "..") {
    currentDirectoryID = getParentIdFromEntry(currentDirectoryID);
    currentDirectoryPath = getDirPath(currentDirectoryID);
    return 0;
  }
  // om det inte finns en / så
  workingDirID = findWorkingID(dirpath);
  if (workingDirID == 0) {
    nyId = getEntryByName(dirpath, currentDirectoryID);
    if (nyId != 0 || nyId == currentDirectoryID) {
      currentDirectoryID = nyId;
      currentDirectoryPath = getDirPath(nyId);
    } else if (nyId == 0) {
    }
  } else {
    nyId = getIdAfterStepInToDir(dirpath, currentDirectoryID);
    if (nyId != 0 || nyId == currentDirectoryID) {
      currentDirectoryID = nyId;
      currentDirectoryPath = getDirPath(nyId);
    }
  }

  return 0;
}

// pwd prints the full path, i.e., from the root directory, to the current
// directory, including the currect directory name
// DONE
int FS::pwd() {
  std::cout << "FS::pwd()\n";
  cout << currentDirectoryPath << endl;
  return 0;
}

// chmod <accessrights> <filepath> changes the access rights for the
// file <filepath> to <accessrights>.
int FS::chmod(std::string accessrights, std::string filepath) {
  std::cout << "FS::chmod(" << accessrights << "," << filepath << ")\n";
  if (!(accessrights == "1" || accessrights == "2" || accessrights == "3" ||
        accessrights == "4" || accessrights == "5" || accessrights == "6" ||
        accessrights == "7")) {
    cout << "Error! Access rights was not entered correctly!" << endl;
    return 0;
  }
  int workingDirID = findWorkingID(filepath);
  string fileName = "";
  if (workingDirID == -1) {
    cout << "ERROR! Path doesn't exist!" << endl;
    return 0;
  } else if (workingDirID == 0) {
    workingDirID = currentDirectoryID;
    fileName = filepath;
  } else {
    fileName = getNameFromPath(filepath);
  }

  uint8_t file_data[BLOCK_SIZE];
  int rightsVar = stoi(accessrights);
  int fileID = getEntryByName(fileName, workingDirID);
  if (fileID != 0) {
    disk.read(fileID, file_data);
  }
  file_data[rightsIndex] = rightsVar;
  disk.write(fileID, file_data);
  return 0;
}
